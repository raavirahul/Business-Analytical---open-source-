#
# This is a Shiny web application. You can run the application by clicking
# the 'Run App' button above.
#
# Find out more about building applications with Shiny here:
#
#    http://shiny.rstudio.com/
#

library(shiny)
library(shinydashboard)
library(ggplot2)
library(dplyr)
library(lubridate)
library(scales)
library(tidyverse)
library(maps)
library(plotly)
library(sf)
library(leaflet)
if (!requireNamespace("rnaturalearthdata", quietly = TRUE)) {
  install.packages("rnaturalearthdata")
}
library(rnaturalearth)
library(viridis)
library(reshape2)



# Load your dataset
data <- read.csv("shiny_basetable.csv")
# Define UI for the application
ui <- dashboardPage(
  skin = "green",
  dashboardHeader(title = "GAMBLINGANALYSIS"),
  dashboardSidebar(
    sidebarMenu(
      menuItem("Geographical View", tabName = "map"),
      menuItem("User", tabName = "Users"),
      menuItem("Profit Metric", tabName = "pm")),
      menuItem("Summary Stats", tabName = "stat")),
  dashboardBody(
    tabItems(
      tabItem(tabName = "map",
              fluidRow(
                box(leafletOutput("map"), title = "Geographical Map", width = 50),
                box(plotOutput("ggPlot"), title = "Application Description Distribution", width = 6),
                box(plotlyOutput("countryPlot"), title = "Country Distribution")
              )),
      tabItem(tabName = "Users",
              fluidRow(
                box(plotlyOutput("languagePlot"), title = "Language Distribution"),
                box(plotOutput("genderPlot"), title = "Gender Distribution"),
                box(plotOutput("recencyPlot"), title = "Recency Measures"),
                box(plotlyOutput("barPlot"),title = "Mean Lor By country"),
                )),
      tabItem(tabName = "pm",
              fluidPage(
                titlePanel("Interactive profitability scatterplot per type of Game"),
                sidebarLayout(
                  sidebarPanel(
                    # Add the select box to choose the preferred metric
                    selectInput("profit_metric", "Select Profit Metric:",
                                choices = c(
                                  "Sports book fixed odd",
                                  "Sports book live action",
                                  "Casino Chartwell",
                                  "Games VS",
                                  "Games bwin",
                                  "Casino BossMedia",
                                  "Supertoto"
                                ),
                                selected = "Sports book fixed odd")
                  ),
                  mainPanel(
                    # Plotly visualization
                    plotlyOutput("financialScatter")
                  )
                )
              )
      ),
      tabItem(tabName = "stat",
          fluidPage(
            titlePanel("Summary Statistics"),
                    fluidRow(
                      sidebarLayout(
                        sidebarPanel(width=2,
                                     selectInput("bets_bucket", "Select BetsBucket:", choices = unique(data$BetsBucket))),
                        dashboardBody(
                          fluidRow(
                            # Aggiungi i valueBox qui
                            valueBoxOutput("profit_margin", width = 3),
                            valueBoxOutput("profit_margin_avg", width = 3),
                            valueBoxOutput("total_buy", width = 3),
                            valueBoxOutput("total_sell", width = 3),
                            valueBoxOutput("average_buy", width = 3),
                            valueBoxOutput("average_sell", width = 3)
                          ),
                          fluidRow(
                            # Tabella dei dati sommario
                            tableOutput("summary_table")
                          ),))
                    )
          )
      ))))


server <- function(input, output) {
  data_aggregated <- data %>%
    group_by(`Country.Name`) %>%
    summarise(AverageProfitPerUser = mean(`Profit_9m_Sports.book.fixed.odd`, na.rm = TRUE)) %>%
    filter(!is.na(AverageProfitPerUser)) %>%
    ungroup()
  
  # Get world countries data
  countries <- ne_countries(scale = "medium", returnclass = "sf")
  
  # Reproject countries to WGS84 (EPSG:4326) projection if needed
  if (!identical(st_crs(countries), st_crs("+proj=longlat +datum=WGS84"))) {
    countries <- st_transform(countries, crs = st_crs("+proj=longlat +datum=WGS84"))
  }
  
  # Merge your data with the spatial data, excluding countries with NA average profit
  countries_data <- merge(countries, data_aggregated, by.x = "name", by.y = "Country.Name") %>%
    filter(!is.na(AverageProfitPerUser))
  pal <- colorNumeric(palette = viridis(10), domain = countries_data$AverageProfitPerUser)
  
  # Rendered the leaflet map
  output$map <- renderLeaflet({
    leaflet(countries_data) %>%
      addProviderTiles(providers$CartoDB.Positron) %>%
      addPolygons(fillColor = ~pal(AverageProfitPerUser),
                  fillOpacity = 0.7, 
                  color = "#FFFFFF", 
                  weight = 1,
                  opacity = 1,
                  label = ~paste(name, ": ", round(AverageProfitPerUser, 2)),
                  highlightOptions = highlightOptions(weight = 3,
                                                      color = "#666",
                                                      fillOpacity = 0.7,
                                                      bringToFront = TRUE)) %>%
      addLegend(pal = pal, values = ~AverageProfitPerUser, opacity = 0.7, title = "Average Profit Per User")
  })
  uc <- data %>%
    group_by(Application.Description) %>%
    summarise(NumUsers = n_distinct(UserID))
  uc <- uc %>%
    filter(Application.Description!= "0")


  
  limit <- 150
  
  # Rendering the bar graph using ggplot in Shiny
  output$ggPlot <- renderPlot({
    ggplot(uc, aes(y = Application.Description, x = NumUsers, fill = Application.Description)) +
      geom_bar(stat = "identity") +
      labs(title = "Number of Users by Application Description",
           y = "Application Description",
           x = "Number of Users") +
      theme_minimal() +
      theme(axis.text.x = element_text(angle = 45, hjust = 1))
  })
  # Calculating language description proportions
  language_proportions <- reactive({
    prop.table(table(data$Language.Description))
  })
  
  # Render language distribution plot
  output$languagePlot <- renderPlotly({
    plot_ly(
      x = language_proportions(),
      y = names(language_proportions()),
      type = "bar",
      orientation = 'h',
      marker = list(color = heat.colors(length(language_proportions())))
    ) %>% 
      layout(
        title = "Language Distribution",
        xaxis = list(title = "Proportion"),
        yaxis = list(title = "Language Description")
      )
  })
  
  # Calculating country distribution proportions and sorting
  country_proportions <- reactive({
    # Calculate the table of counts
    country_counts <- table(data$`Country.Name`)
    
    # Convert to a dataframe and sort
    country_df <- as.data.frame(country_counts, stringsAsFactors = FALSE)
    colnames(country_df) <- c("Country", "Count")
    country_df <- country_df %>%
      arrange(desc(Count)) %>%
      mutate(Proportion = Count / sum(Count))
    
    # Group all countries outside of the top 14 into "Other"
    top_countries <- country_df[1:14, ]
    top_countries <- rbind(top_countries, 
                           data.frame(Country = "Other", 
                                      Count = sum(country_df$Count[-(1:14)]), 
                                      Proportion = sum(country_df$Proportion[-(1:14)])))
    
    top_countries$Country <- factor(top_countries$Country, levels = top_countries$Country)
    top_countries
  })
  
  # Rendering the country distribution plot
  output$countryPlot <- renderPlotly({
    # Get the proportions and reorder based on the Count for plotting
    top_countries <- country_proportions()
    
    plot_ly(
      x = top_countries$Proportion,
      y = top_countries$Country,
      type = 'bar',
      orientation = 'h', # Horizontal bar chart
      marker = list(color = heat.colors(length(top_countries$Proportion)))
    ) %>%
      layout(
        title = "Country Distribution",
        xaxis = list(title = "Proportion"),
        yaxis = list(title = "Country", categoryorder = "total ascending"), # Ensure categories are ordered
        barmode = 'stack'
      )
  })
  output$genderPlot <- renderPlot({
    # Ensure the Gender column is a factor and has the correct levels
    data$Gender <- factor(data$Gender, levels = c("F", "M"))
    
    # Calculate the proportions
    gender_proportions <- prop.table(table(data$Gender))
    
    # Define custom colors for the bars
    colors <- c("F" = "pink", "M" = "lightblue")
    
    # Creating the barplot with custom colors based on the factor levels
    barplot(gender_proportions, col = colors[levels(data$Gender)], main = "Gender Distribution", xlab = "Gender", ylab = "Proportion")
    
    # Adding labels with percentages on top of the bars for non-zero proportions
    if (length(gender_proportions) > 1) {
      text(seq_along(gender_proportions), gender_proportions, labels = paste0(round(gender_proportions * 100, 1), "%"), pos = 3, cex = 0.8, col = "black")
    }
  })
  
  output$recencyPlot <- renderPlot({
    hist(data$Recency, col = "orange", main = "Distribution of Recency", xlab = "Recency", ylab = "Frequency_Category")
  })
  
  output$barPlot <- renderPlotly({
    # Remove NAs and compute mean LOR by country
    shiny_basetable_cleaned <- data %>%
      filter(!is.na(Country.Name), !is.na(LOR))
    
    mean_lor_by_country <- shiny_basetable_cleaned %>%
      group_by(Country.Name) %>%
      summarise(MeanLOR = mean(LOR, na.rm = TRUE)) %>%
      ungroup()
    
    # Sort by MeanLOR and get the top 20
    top_countries_lor <- mean_lor_by_country %>%
      arrange(desc(MeanLOR)) %>%
      slice_max(order_by = MeanLOR, n = 20)
    
    # Create the bar plot for the top 20 countries
    plot_ly(
      data = top_countries_lor,
      x = ~MeanLOR,
      y = ~fct_reorder(Country.Name, MeanLOR),
      type = 'bar',
      orientation = 'h', # Horizontal bar chart
      marker = list(color = 'Orange')
    ) %>%
      layout(
        title = "Top 20 Countries by Mean LOR",
        xaxis = list(title = "Mean Length of Relationship (LOR)"),
        yaxis = list(title = "Country", autorange = "reversed") # Ensure countries are ordered correctly
      )
  })
  
  
  
  filtered_data <- reactive({
    if (length(input$selectedGames) == 0) {
      daily_averages # If no game is selected, show all games
    } else {
      daily_averages %>%
        filter(ProductDescription %in% input$selectedGames)
    }
  })
  
  # Reactive expression to determine the y-axis data based on input
  yData <- reactive({
    switch(input$dataType,
           "Stakes" = "AverageStakes",
           "Winnings" = "AverageWinnings",
           "Bets" = "AverageBets")
  })
  
  output$financialScatter <- renderPlotly({
    metrica_profitto <- switch(input$profit_metric,
                               "Sports book fixed odd" = data$Profit_Sports_book_fixed_odd,
                               "Sports book live action" = data$Profit_Sports_book_live_action,
                               "Casino Chartwell" = data$Profit_Casino_Chartwell,
                               "Games VS" = data$Profit_Games_VS,
                               "Games bwin" = data$Profit_Games_bwin,
                               "Casino BossMedia" = data$Profit_Casino_BossMedia,
                               "Supertoto" = data$Profit_Supertoto)
    
    plot_ly(data, x = ~TotalStakes, y = ~metrica_profitto, size = I(5),
            color = metrica_profitto,
            marker = list(symbol = 'circle', sizemode = 'diameter'),
            text = ~paste('UserID: ', UserID, '<br>Total Stakes: ', TotalStakes,
                          '<br>', input$profit_metric, ': ', format(metrica_profitto, nsmall = 2)),
            hoverinfo = 'text') %>%
      layout(
        title = paste(input$profit_metric, 'over Total Stakes'),
        xaxis = list(title = 'Total Stakes'),
        yaxis = list(title = input$profit_metric, 'Profit'),
        showlegend = FALSE
      )
  })
  
  
  fd <- reactive({
    data %>%
      filter(BetsBucket == input$bets_bucket)
  })
  
  summary_data_filtered <- reactive({
    fd() %>%
      group_by(BetsBucket) %>%
      summarize(
        CasinoProfitMargin = mean(casino_profit_margin, na.rm = TRUE),
        CasinoProfitMarginAvg = mean(casino_profit_margin_avg, na.rm = TRUE),
        TotalBuy = round(sum(Total_Buy, na.rm = TRUE), 2),
        TotalSell = round(sum(Total_Sell, na.rm = TRUE), 2),
        AverageBuy = mean(AverageBuy, na.rm = TRUE),
        AverageSell = mean(AverageSell, na.rm = TRUE)
      )
  })
  
  # Add the valueBox
  output$profit_margin <- renderValueBox({
    valueBox(
      value = round(summary_data_filtered()$CasinoProfitMargin, 2),
      subtitle = "Casino Profit Margin",
      icon = icon("chart-line")
    )
  })
  
  output$profit_margin_avg <- renderValueBox({
    valueBox(
      value = round(summary_data_filtered()$CasinoProfitMarginAvg, 2),
      subtitle = "Casino Profit Margin Average per User",
      icon = icon("chart-line")
    )
  })
  
  output$total_buy <- renderValueBox({
    valueBox(
      value = summary_data_filtered()$TotalBuy,
      subtitle = "Total Buy",
      icon = icon("shopping-cart")
    )
  })
  
  output$total_sell <- renderValueBox({
    valueBox(
      value = summary_data_filtered()$TotalSell,
      subtitle = "Total Sell",
      icon = icon("dollar-sign")
    )
  })
  
  output$average_buy <- renderValueBox({
    valueBox(
      value = round(summary_data_filtered()$AverageBuy, 2),
      subtitle = "Average Buy",
      icon = icon("shopping-cart")
    )
  })
  
  output$average_sell <- renderValueBox({
    valueBox(
      value = round(summary_data_filtered()$AverageSell, 2),
      subtitle = "Average Sell",
      icon = icon("dollar-sign")
    )
  })
  
  
  }


# Run the application 
shinyApp(ui = ui, server = server)
